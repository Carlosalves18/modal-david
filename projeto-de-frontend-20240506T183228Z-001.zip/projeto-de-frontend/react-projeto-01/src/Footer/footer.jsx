import './footer.css'
import dogmeme from '/memedogg.jpg'


const Footer = () =>{
    return(
        <footer className="Footer">
            <img src={dogmeme}  />
            <p>&copy; Todos os direitos reservados</p>
        </footer>

    )
}
export default Footer