const luana = {
    cliente: 'Luana',
    idade: 27,
    compras: [
      { nome: 'Notebook', preco: 'R$ 2500' },
      { nome: 'Geladeira', preco: 'R$ 3000' },
      { nome: 'Smartphone', preco: 'R$ 1500' },
    ],
    ativa: true,
};
  
const mario = {
    cliente: 'Mario',
    idade: 31,
    compras: [
      { nome: 'Notebook', preco: 'R$ 2500' },
      { nome: 'Geladeira', preco: 'R$ 3000' },
      { nome: 'Smartphone', preco: 'R$ 1500' },
      { nome: 'Guitarra', preco: 'R$ 3500' },
    ],
    ativa: false,
};
  
const App = () => {
    const dados = luana
    
    
    ;

  
    const totalGasto = dados.compras
      .map((item) => parseFloat(item.preco.replace('R$ ', '')))
      .reduce((acc, cur) => acc + cur, 0);
  
    const situacao = dados.ativa ? 'Ativa' : 'Inativa';
    const corSituacao = dados.ativa ? 'green' : 'red';
    const mensagem = totalGasto > 10000 ? 'Gasto elevado' : null;
  
    return (
      <div>
        <h2 style={{ color: corSituacao }}>Cliente: {dados.cliente}</h2>
        <p style={{ color: corSituacao }}>Idade: {dados.idade}</p>
        <p style={{ color: corSituacao }}>Situação: {situacao}</p>
        <p style={{ color: corSituacao }}>Total Gasto: R$ {totalGasto}</p>
        {mensagem && <p style={{ color: 'red' }}>{mensagem}</p>}
      </div>
    );
};

export default App;