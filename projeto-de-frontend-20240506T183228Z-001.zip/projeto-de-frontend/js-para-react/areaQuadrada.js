// export  const areaQuadrado = (lado) => {
//     return lado * lado
// }
// export const perimetroQuadrado = (lado) =>{
//     return 4 * lado 
// }

