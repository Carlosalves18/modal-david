// import { areaQuadrada, perimetroQuadrado } from "./areaQuadrada";

// console.log(perimetroQuadrado(5))

// Arrow Function

// function UpperName(name){
//     console.log(name.toUpperCase());
// }

// const LowerName = (name) =>{
//     console.log(name.toLowerCase())
// }
// LowerName("DUDU")

// Crie uma função que conte a quantidade de caracteres
// de uma string. Faça utilizando a declaração clássica
// de função e a Arrow Function.

// function ContaLetras (name){
//     console.log(name.length)
// }

//  function ContaLetrasArrow (name){
//     console.log(name.length)
// }

// //Destructuring

// const MouseClick = (event) =>{
//     const clientX = event.clientX
//     const clientT = event.clientT
//     console.log(clientX,clientT)
    
// }

// const MouseDown = (event) =>{
//     const {clientX,clientT} = event;
//     console.log(clientX,clientT)
// }

// const HandleMouse = ({clientX, clientT}) =>{
//     console.log(clientX,clientT)
// }

// document.documentElement.addEventListener('mousemove',HandleMouse)

// Arrays

// const cursos = ['Informatica','Eletrotécnica','Petroquímica','Moda']

// const [curso1,curso2] = cursos

// cusos1 retorna 'informática'

//Spread

// const numeros = [1,20,3,53,9,22,13,7]

// const frutas = ['pera','mamão','maça']

// const outrasF = ['banana','jabuticaba','romã', ...frutas]

// const meusI = ['Gabriel','Rayane']
// const outrosI = ['Lucas','Karina']

// const tdsI = [...meusI,...outrosI,'Luana','Jezabel']


// console.log(tdsI) Exibe todos os irmãos

//Rest

// function listaDeClientes  (empresa,...client) {
//     client.forEach((cliente) => {
//             console.log(cliente, empresa)
//     });
// }
// listaDeClientes('eu','ei','ou','me')

//fecth

// fetch('https://viacep.com.br/es/57045005/json/')
// .then((response) =>{
//     console.log(response.json())
// })

// const fecthURL = async (url) => {
//     const response = await fetch(url)
//     const json = response.jsonret
//     return json
// }
// fecthURL('https://viacep.com.br/es/57045005/json/').
// then((cep) =>{

//     const elemento = document.getElementById

// } 
//  document.innerHTML(`Rua: ${cep.logradouro}`,`Bairro: ${cep.bairro}`))

// arrays (filter e map)

// const precos =[

//     'R$ 300',
//     'R$ 150',
//     '200',
//     'R$ 400',
//     ' 500',
//     'Meus dados',
//     'Contas a pagar'
    
// ]
// const precosF = precos.filter((preco) => preco.includes('0'))

// const precosN = precos.map((preco) => Number(preco.replace('R$','')));
// console.log(precosN)

// //Operados Ternários
// const macbook = 6000
// const galaxyBook = 5000
// const maisC = macbook > galaxyBook ? "MacBook" : "GalaxyBook"

// console.log(maisC)

// if(macbook > galaxyBook){
//     console.log("MacBook é mais caro!")
// }else{
//     console.log("GalaxyBook é mais caro!")
// }

