import React from "react"
// Estados
// O estado de uma aplicação representa as características dela naquele momento.

// const App = () => {
    
//     const ativo = true

//     return(
//         <button disabled={!ativo}>{ativo ? "Botão ativo" : "Botão inativo"}</button>
//     )
// }

// export default App

//Hooks
// Os hooks são funções especiais do react que permitem controlarmos o estado e o ciclo de vida de componentes.

//-------------------------------------------

//react.useState

const App = () => {
    
    const [ativo, setAtivo] = React.useState(true)
    const [contar, setContar] = React.useState(0)
    
    return(
        <>
        <button onClick={() => setAtivo(!ativo)}>
            {ativo ? "Botão ativo" : "Botão inativo"}
        </button>

        <button onClick={() => setContar(contar + 1)}>
            {contar}
        </button>
        </>
    )
}

export default App