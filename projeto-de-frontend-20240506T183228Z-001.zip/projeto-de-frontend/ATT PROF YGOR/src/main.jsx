import React from 'react'
import ReactDOM from 'react-dom/client'
import Exercicio2 from './exercicio2'
import Att from './attSala'





ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
   <Exercicio2/>
   <Att/>
  </React.StrictMode>,
)
